jQuery(document).ready(function($) {
    //TODO
});