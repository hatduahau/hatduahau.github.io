<footer class="u-align-center u-clearfix u-container-align-center u-footer u-palette-5-dark-3 u-footer" id="sec-ad58">
  <div class="u-clearfix u-sheet u-sheet-1">
    <p class="u-small-text u-text u-text-variant u-text-1">Sample text. Click to select the text box. Click again or double click to start editing the text.</p>
  </div>
</footer>